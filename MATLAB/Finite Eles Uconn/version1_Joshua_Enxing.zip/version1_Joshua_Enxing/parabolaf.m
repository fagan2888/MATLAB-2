%Joshua Enxing
%Code written to approximate the boundary during mesh refinements

function pt = parabolaf(p1,p2)

x = (p1(1)+p2(1))/2;
y = x^2;
pt = [x y];
